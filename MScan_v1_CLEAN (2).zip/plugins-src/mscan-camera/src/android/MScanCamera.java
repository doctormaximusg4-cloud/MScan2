package com.mintsog.mscan;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.Collections;

public class MScanCamera extends CordovaPlugin {
    private static final int REQ=9101;
    private TextureView view;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private HandlerThread thread;
    private Handler handler;
    private CallbackContext pending;
    private boolean opening=false;

    @Override public boolean execute(String action, JSONArray args, CallbackContext cb) throws JSONException{
        if("start".equals(action)){ start(cb); return true; }
        if("stop".equals(action)){ stop(cb); return true; }
        return false;
    }

    private void start(CallbackContext cb){
        if(!cordova.hasPermission(Manifest.permission.CAMERA)){
            pending=cb;
            cordova.requestPermission(this,REQ,Manifest.permission.CAMERA);
            return;
        }
        createView(cb);
    }

    @Override public void onRequestPermissionResult(int requestCode,String[] permissions,int[] results) throws JSONException{
        if(requestCode!=REQ) return;
        CallbackContext cb=pending; pending=null;
        if(cb==null) return;
        if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) createView(cb);
        else cb.error("Camera permission denied");
    }

    private void createView(CallbackContext cb){
        cordova.getActivity().runOnUiThread(()->{
            try{
                View web=webView.getView();
                ViewGroup parent=(ViewGroup)web.getParent();
                if(parent==null){ cb.error("WebView parent not found"); return; }

                parent.setBackgroundColor(Color.TRANSPARENT);
                web.setBackgroundColor(Color.TRANSPARENT);

                if(view==null){
                    view=new TextureView(cordova.getActivity());
                    ViewGroup.LayoutParams lp=new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    );
                    int idx=Math.max(0,parent.indexOfChild(web));
                    parent.addView(view,idx,lp);
                    web.bringToFront();
                    startThread();
                    view.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
                        @Override public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){ openCamera(cb); }
                        @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){}
                        @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s){ closeCamera(); return true; }
                        @Override public void onSurfaceTextureUpdated(SurfaceTexture s){}
                    });
                }

                if(view.isAvailable() && camera==null && !opening) openCamera(cb);
            }catch(Exception e){ cb.error("Camera view error: "+e.getMessage()); }
        });
    }

    private void openCamera(CallbackContext cb){
        if(opening || camera!=null) return;
        opening=true;
        try{
            CameraManager m=(CameraManager)cordova.getActivity().getSystemService(Context.CAMERA_SERVICE);
            if(m==null){ opening=false; cb.error("CameraManager unavailable"); return; }

            String selected=null;
            for(String id:m.getCameraIdList()){
                Integer facing=m.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if(facing!=null && facing==CameraCharacteristics.LENS_FACING_BACK){ selected=id; break; }
            }
            if(selected==null){ opening=false; cb.error("No rear camera found"); return; }
            if(!cordova.hasPermission(Manifest.permission.CAMERA)){ opening=false; cb.error("Camera permission missing"); return; }

            m.openCamera(selected,new CameraDevice.StateCallback(){
                @Override public void onOpened(CameraDevice c){ opening=false; camera=c; createPreview(cb); }
                @Override public void onDisconnected(CameraDevice c){ opening=false; c.close(); camera=null; cb.error("Camera disconnected"); }
                @Override public void onError(CameraDevice c,int error){ opening=false; c.close(); camera=null; cb.error("Camera2 error "+error); }
            },handler);
        }catch(Exception e){ opening=false; cb.error("Open camera failed: "+e.getMessage()); }
    }

    private void createPreview(CallbackContext cb){
        try{
            SurfaceTexture texture=view.getSurfaceTexture();
            if(texture==null){ cb.error("SurfaceTexture unavailable"); return; }
            texture.setDefaultBufferSize(1280,720);
            Surface surface=new Surface(texture);
            CaptureRequest.Builder b=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(surface);
            b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);

            camera.createCaptureSession(Collections.singletonList(surface),new CameraCaptureSession.StateCallback(){
                @Override public void onConfigured(CameraCaptureSession s){
                    session=s;
                    try{
                        session.setRepeatingRequest(b.build(),null,handler);
                        cb.success("CAM OK");
                    }catch(Exception e){ cb.error("Preview start failed: "+e.getMessage()); }
                }
                @Override public void onConfigureFailed(CameraCaptureSession s){ cb.error("Preview configuration failed"); }
            },handler);
        }catch(Exception e){ cb.error("Preview setup failed: "+e.getMessage()); }
    }

    private void startThread(){
        if(thread!=null) return;
        thread=new HandlerThread("MScanCamera2");
        thread.start();
        handler=new Handler(thread.getLooper());
    }

    private void closeCamera(){
        try{ if(session!=null) session.close(); }catch(Exception ignored){}
        session=null;
        try{ if(camera!=null) camera.close(); }catch(Exception ignored){}
        camera=null; opening=false;
    }

    private void stop(CallbackContext cb){
        cordova.getActivity().runOnUiThread(()->{
            closeCamera();
            if(view!=null){
                try{
                    ViewGroup p=(ViewGroup)view.getParent();
                    if(p!=null) p.removeView(view);
                }catch(Exception ignored){}
                view=null;
            }
            if(thread!=null){ thread.quitSafely(); thread=null; handler=null; }
            cb.success();
        });
    }

    @Override public void onDestroy(){
        closeCamera();
        if(thread!=null) thread.quitSafely();
        super.onDestroy();
    }
}