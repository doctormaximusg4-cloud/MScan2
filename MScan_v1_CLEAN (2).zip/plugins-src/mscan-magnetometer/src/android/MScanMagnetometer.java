package com.mintsog.mscan;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MScanMagnetometer extends CordovaPlugin implements SensorEventListener {
    private SensorManager manager;
    private Sensor sensor;
    private CallbackContext stream;
    private boolean running=false;

    @Override protected void pluginInitialize(){
        Context c=cordova.getActivity().getApplicationContext();
        manager=(SensorManager)c.getSystemService(Context.SENSOR_SERVICE);
        if(manager!=null) sensor=manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
    }

    @Override public boolean execute(String action, JSONArray args, CallbackContext cb) throws JSONException{
        if("start".equals(action)){ start(args.optJSONObject(0),cb); return true; }
        if("stop".equals(action)){ stop(cb); return true; }
        return false;
    }

    private void start(JSONObject options, CallbackContext cb){
        if(manager==null || sensor==null){ cb.error("This device has no magnetometer."); return; }
        if(running) manager.unregisterListener(this);
        int hz=50;
        if(options!=null) hz=options.optInt("frequency",50);
        hz=Math.max(1,Math.min(100,hz));
        stream=cb;
        running=manager.registerListener(this,sensor,1000000/hz);
        if(!running){ stream=null; cb.error("Unable to register magnetometer listener."); return; }
        PluginResult p=new PluginResult(PluginResult.Status.NO_RESULT);
        p.setKeepCallback(true);
        cb.sendPluginResult(p);
    }

    private void stop(CallbackContext cb){
        if(manager!=null) manager.unregisterListener(this);
        running=false; stream=null; cb.success();
    }

    @Override public void onSensorChanged(SensorEvent e){
        if(!running || stream==null || e.sensor.getType()!=Sensor.TYPE_MAGNETIC_FIELD) return;
        float x=e.values[0],y=e.values[1],z=e.values[2];
        double m=Math.sqrt(x*x+y*y+z*z);
        try{
            JSONObject d=new JSONObject();
            d.put("x",x); d.put("y",y); d.put("z",z); d.put("magnitude",m); d.put("timestamp",e.timestamp);
            PluginResult r=new PluginResult(PluginResult.Status.OK,d);
            r.setKeepCallback(true); stream.sendPluginResult(r);
        }catch(JSONException ignored){}
    }

    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}
    @Override public void onDestroy(){ if(manager!=null) manager.unregisterListener(this); super.onDestroy(); }
}